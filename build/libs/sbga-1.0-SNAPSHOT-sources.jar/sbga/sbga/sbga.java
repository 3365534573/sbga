package sbga.sbga;

import net.fabricmc.api.ModInitializer;

public class sbga implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
